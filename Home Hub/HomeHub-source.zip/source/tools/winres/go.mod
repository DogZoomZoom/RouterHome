module winrestool

go 1.24.7

replace golang.org/x/image => github.com/golang/image v0.24.0

require github.com/tc-hib/winres v0.2.1

require (
	github.com/nfnt/resize v0.0.0-20180221191011-83c6a9932646 // indirect
	golang.org/x/image v0.12.0 // indirect
)
