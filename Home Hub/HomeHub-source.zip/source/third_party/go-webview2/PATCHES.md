# Changes to go-webview2

This folder is [wailsapp/go-webview2](https://github.com/wailsapp/go-webview2) at commit
`e08e9397f04ad0b1050d7e5bdc8e27faddc87987` (2025-11-14), MIT License (see `LICENSE`), with the fixes below.
The full diff against that commit is in [`homehub-changes.diff`](homehub-changes.diff).

1. **Callbacks with string parameters** (`pkg/webview2`): several generated event handlers took Go `string`
   parameters, which `syscall.NewCallback` can't accept, so the program panicked at start-up. They now take
   `*uint16` and convert with `windows.UTF16PtrToString`. `tools/cbcheck` checks every callback.
2. **Out-parameters passed by value** (`pkg/webview2`, 111 places): getters such as
   `ICoreWebView2Certificate.ToPemEncoding` and `ICoreWebView2.GetSource` passed the result variable instead of
   its address, so they failed or returned nothing.
3. **Versioned interfaces missing their parents** (`pkg/webview2`, 88 interfaces): vtables such as
   `ICoreWebView2_14Vtbl` didn't include the methods inherited from the earlier versions, so later methods
   (e.g. `AddServerCertificateErrorDetected`) called the wrong slot.
4. **Accelerator keys** (`pkg/edge/chromium.go`): when the `AcceleratorKeyCallback` handled a key, the handler
   fell through instead of returning, so Home Hub's shortcuts (Ctrl+1…9, Ctrl+Tab, F5, Ctrl+L) misbehaved while
   a web page had focus. The `pkg/edge` user-agent getters also had an out-parameter passed by value (fix 2).
5. **Removed** `pkg/edge/capabilities_test.go` and `cookies_test.go`, which need a desktop session and the
   testify module.
6. **Additions** (`pkg/edge/expose.go`): `RawWebView()` returns the `ICoreWebView2` pointer for the full
   bindings, and `Close()` shuts a browser down when a tab is removed.
