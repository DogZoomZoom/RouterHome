//go:build windows

package edge

import "unsafe"

// RawWebView returns the underlying ICoreWebView2 COM pointer so callers can
// use the full generated bindings in pkg/webview2.
func (e *Chromium) RawWebView() unsafe.Pointer { return unsafe.Pointer(e.webview) }

// Close shuts this browser down (ICoreWebView2Controller::Close). The Chromium
// value must not be used afterwards.
func (e *Chromium) Close() {
	if e.controller == nil {
		return
	}
	_, _, _ = e.controller.vtbl.Close.Call(uintptr(unsafe.Pointer(e.controller)))
	e.controller.Release()
	e.controller = nil
	e.webview = nil
}
