//go:build windows

package webview2

import (
	"unsafe"

	"golang.org/x/sys/windows"
)

type ICoreWebView2ExecuteScriptCompletedHandlerVtbl struct {
	IUnknownVtbl
	Invoke ComProc
}

type ICoreWebView2ExecuteScriptCompletedHandler struct {
	Vtbl *ICoreWebView2ExecuteScriptCompletedHandlerVtbl
	impl ICoreWebView2ExecuteScriptCompletedHandlerImpl
}

func (i *ICoreWebView2ExecuteScriptCompletedHandler) AddRef() uintptr {
	refCounter, _, _ := i.Vtbl.AddRef.Call(uintptr(unsafe.Pointer(i)))
	return refCounter
}

func ICoreWebView2ExecuteScriptCompletedHandlerIUnknownQueryInterface(this *ICoreWebView2ExecuteScriptCompletedHandler, refiid, object uintptr) uintptr {
	return this.impl.QueryInterface(refiid, object)
}

func ICoreWebView2ExecuteScriptCompletedHandlerIUnknownAddRef(this *ICoreWebView2ExecuteScriptCompletedHandler) uintptr {
	return this.impl.AddRef()
}

func ICoreWebView2ExecuteScriptCompletedHandlerIUnknownRelease(this *ICoreWebView2ExecuteScriptCompletedHandler) uintptr {
	return this.impl.Release()
}

// Windows passes an LPCWSTR here; a Go string is 16 bytes and would make
// windows.NewCallback panic at package init, so take the pointer and convert.
func ICoreWebView2ExecuteScriptCompletedHandlerInvoke(this *ICoreWebView2ExecuteScriptCompletedHandler, errorCode uintptr, result *uint16) uintptr {
	return this.impl.ExecuteScriptCompleted(errorCode, windows.UTF16PtrToString(result))
}

type ICoreWebView2ExecuteScriptCompletedHandlerImpl interface {
	IUnknownImpl
	ExecuteScriptCompleted(errorCode uintptr, result string) uintptr
}

var ICoreWebView2ExecuteScriptCompletedHandlerFn = ICoreWebView2ExecuteScriptCompletedHandlerVtbl{
	IUnknownVtbl{
		NewComProc(ICoreWebView2ExecuteScriptCompletedHandlerIUnknownQueryInterface),
		NewComProc(ICoreWebView2ExecuteScriptCompletedHandlerIUnknownAddRef),
		NewComProc(ICoreWebView2ExecuteScriptCompletedHandlerIUnknownRelease),
	},
	NewComProc(ICoreWebView2ExecuteScriptCompletedHandlerInvoke),
}

func NewICoreWebView2ExecuteScriptCompletedHandler(impl ICoreWebView2ExecuteScriptCompletedHandlerImpl) *ICoreWebView2ExecuteScriptCompletedHandler {
	return &ICoreWebView2ExecuteScriptCompletedHandler{
		Vtbl: &ICoreWebView2ExecuteScriptCompletedHandlerFn,
		impl: impl,
	}
}
